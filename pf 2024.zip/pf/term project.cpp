#include <iostream>
#include <string>
using namespace std;

const int MAX = 100;

// Structure - Same structure, different fields
struct Patient {
    string name;
    string patientID;
    string illness;
    string doctor;
    int bedNumber;
    int age;
};

Patient ward[MAX];
int countPatients = 0;

// ================= FUNCTIONS =================

void addPatient() {
    if (countPatients >= MAX) {
        cout << "Ward is full!\n";
        return;
    }

    cout << "\nEnter Patient Details:\n";
    cout << "Name: ";
    cin.ignore();
    getline(cin, ward[countPatients].name);

    cout << "Patient ID (Unique): ";
    getline(cin, ward[countPatients].patientID);

    cout << "Illness: ";
    getline(cin, ward[countPatients].illness);

    cout << "Assigned Doctor: ";
    getline(cin, ward[countPatients].doctor);

    cout << "Bed Number: ";
    cin >> ward[countPatients].bedNumber;

    cout << "Age: ";
    cin >> ward[countPatients].age;

    countPatients++;
    cout << "Patient registered successfully!\n";
}

// ------------------------------------------------

void displayPatients() {
    if (countPatients == 0) {
        cout << "No patients currently in the ward.\n";
        return;
    }

    cout << "\n===== Ward Patient List =====\n";
    for (int i = 0; i < countPatients; i++) {
        cout << "\nPatient Record " << i + 1 << ":\n";
        cout << "Name: " << ward[i].name << endl;
        cout << "ID: " << ward[i].patientID << endl;
        cout << "Diagnosis: " << ward[i].illness << endl;
        cout << "Doctor: " << ward[i].doctor << endl;
        cout << "Bed: " << ward[i].bedNumber << endl;
        cout << "Age: " << ward[i].age << endl;
    }
}

// ------------------------------------------------

void removePatient() {
    string id;
    cout << "Enter Patient ID to remove: ";
    cin >> id;

    for (int i = 0; i < countPatients; i++) {
        if (ward[i].patientID == id) {
            for (int j = i; j < countPatients - 1; j++) {
                ward[j] = ward[j + 1];
            }
            countPatients--;
            cout << "Record deleted successfully!\n";
            return;
        }
    }
    cout << "Patient not found!\n";
}

// ------------------------------------------------

void modifyPatient() {
    string id;
    cout << "Enter Patient ID to modify: ";
    cin >> id;

    for (int i = 0; i < countPatients; i++) {
        if (ward[i].patientID == id) {
            cout << "Enter new details:\n";
            cin.ignore();
            cout << "Name: ";
            getline(cin, ward[i].name);
            cout << "Diagnosis: ";
            getline(cin, ward[i].illness);
            cout << "Doctor: ";
            getline(cin, ward[i].doctor);
            cout << "Bed Number: ";
            cin >> ward[i].bedNumber;
            cout << "Age: ";
            cin >> ward[i].age;

            cout << "Record updated successfully!\n";
            return;
        }
    }
    cout << "Patient not found!\n";
}

// ------------------------------------------------

void searchByID() {
    string id;
    cout << "Enter Patient ID: ";
    cin >> id;

    for (int i = 0; i < countPatients; i++) {
        if (ward[i].patientID == id) {
            cout << "\nPatient Found:\n";
            cout << ward[i].name << " | Dr. " << ward[i].doctor << endl;
            return;
        }
    }
    cout << "Patient not found!\n";
}

// ------------------------------------------------

void searchByName() {
    string name;
    cout << "Enter Patient Name: ";
    cin.ignore();
    getline(cin, name);

    bool found = false;
    for (int i = 0; i < countPatients; i++) {
        if (ward[i].name == name) {
            cout << "\nFound ID: " << ward[i].patientID << " | Bed: " << ward[i].bedNumber << endl;
            found = true;
        }
    }
    if (!found) cout << "Patient not found!\n";
}

// ------------------------------------------------

void sortByName() {
    for (int i = 0; i < countPatients - 1; i++) {
        for (int j = i + 1; j < countPatients; j++) {
            if (ward[i].name > ward[j].name) {
                swap(ward[i], ward[j]);
            }
        }
    }
    cout << "Records sorted alphabetically by name!\n";
}

// ------------------------------------------------

void sortByAge() {
    for (int i = 0; i < countPatients - 1; i++) {
        for (int j = i + 1; j < countPatients; j++) {
            if (ward[i].age > ward[j].age) {
                swap(ward[i], ward[j]);
            }
        }
    }
    cout << "Records sorted by Age!\n";
}

// ------------------------------------------------

void emergencyFlag() {
    string id;
    cout << "Enter ID for critical status update: ";
    cin >> id;

    for (int i = 0; i < countPatients; i++) {
        if (ward[i].patientID == id) {
            cout << "PATIENT " << ward[i].name << " MARKED FOR IMMEDIATE REVIEW!\n";
            return;
        }
    }
    cout << "Patient not found!\n";
}

// ------------------------------------------------

void dischargeSummary() {
    string id;
    cout << "Enter Patient ID for final discharge: ";
    cin >> id;

    for (int i = 0; i < countPatients; i++) {
        if (ward[i].patientID == id) {
            cout << "Finalizing Discharge for " << ward[i].name << "...\n";
            cout << "Discharge Complete!\n";
            return;
        }
    }
    cout << "Patient not found!\n";
}

// ================= MAIN =================

int main() {
    int choice;

    do {
        cout << "\n===== Hospital Management System =====\n";
        cout << "1. Register New Patient\n";
        cout << "2. Delete Patient Record\n";
        cout << "3. Update Patient Info\n";
        cout << "4. Search by Patient ID\n";
        cout << "5. Search by Name\n";
        cout << "6. Sort Records by Name\n";
        cout << "7. Sort Records by Age\n";
        cout << "8. Display All Patients\n";
        cout << "9. Mark Emergency Case\n";
        cout << "10. Issue Discharge\n";
        cout << "0. Exit System\n";
        cout << "Enter choice: ";
        cin >> choice;

        switch (choice) {
        case 1: addPatient(); break;
        case 2: removePatient(); break;
        case 3: modifyPatient(); break;
        case 4: searchByID(); break;
        case 5: searchByName(); break;
        case 6: sortByName(); break;
        case 7: sortByAge(); break;
        case 8: displayPatients(); break;
        case 9: emergencyFlag(); break;
        case 10: dischargeSummary(); break;
        case 0: cout << "Shutting down...\n"; break;
        default: cout << "Invalid choice!\n";
        }

    } while (choice != 0);

    return 0;
}