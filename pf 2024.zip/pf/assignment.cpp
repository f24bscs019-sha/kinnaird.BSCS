#include <iostream>
#include <string>
using namespace std;

int main()
{
    // Variables (Keeping the same data types as your original)
    int shipPasscode = 7788, enteredPass;
    int loginAttempts = 0;
    float fuelLevel = 1000.0, amount;
    char shipChoice;
    bool systemAccess = false;

    // Log tracking
    string lastActivity = "Docked at Station";
    float lastValue = 0;

    // Welcome Screen
    cout << "=====================================\n";
    cout << "      GALACTIC STARSHIP SYSTEM\n";
    cout << "=====================================\n";
    cout << "System Authorization Required.\n";
    cout << "Security Level: Alpha (3 Tries Max)\n\n";

    // Access Verification (while loop)
    while (loginAttempts < 3)
    {
        cout << "Enter Captain's Passcode: ";
        cin >> enteredPass;

        if (enteredPass == shipPasscode)
        {
            systemAccess = true;
            cout << "\nAccess Granted. Welcome, Captain!\n";
            break;
        }
        else
        {
            loginAttempts++;
            cout << "Access Denied! Security alert in: " << 3 - loginAttempts << "\n";
        }
    }

    // System Lockdown
    if (!systemAccess)
    {
        cout << "\nSHIP LOCKED! Sending coordinates to Federation.\n";
        return 0;
    }

    // Ship Menu (do-while loop)
    do
    {
        cout << "\n=====================================\n";
        cout << "           SHIP COMMAND\n";
        cout << "=====================================\n";
        cout << "1. Fuel Status\n";
        cout << "2. Refuel Ship\n";
        cout << "3. Hyperspace Jump (Consumes Fuel)\n";
        cout << "4. Flight Logs\n";
        cout << "5. Power Down\n";
        cout << "Enter command: ";
        cin >> shipChoice;

        // Command processing (switch statement)
        switch (shipChoice)
        {
        case '1':
            cout << "\nCurrent Fuel Reservoirs: " << fuelLevel << " Liters\n";
            break;

        case '2':
            cout << "\nEnter amount of Fuel to pump: ";
            cin >> amount;

            if (amount > 0 && fuelLevel + amount < 10000) // Max tank check
            {
                fuelLevel += amount;
                lastActivity = "Refuel";
                lastValue = amount;
                cout << "Refueling Complete!\n";
                cout << "New Fuel Level: " << fuelLevel << "\n";
            }
            else
            {
                cout << "Error: Tank Overflow or Invalid Amount!\n";
            }
            break;

        case '3':
            cout << "\nEnter fuel required for jump: ";
            cin >> amount;

            if (amount > 0 && amount <= fuelLevel)
            {
                fuelLevel -= amount;
                lastActivity = "Hyperspace Jump";
                lastValue = amount;
                cout << "Jump Successful! Arrival at New Sector.\n";
                cout << "Remaining Fuel: " << fuelLevel << "\n";
            }
            else
            {
                cout << "Insufficient Fuel for Jump!\n";
            }
            break;

        case '4':
            cout << "\n========== LOGS ==========\n";
            cout << "Last Activity: " << lastActivity << "\n";
            cout << "Value: " << lastValue << " units\n";

            // Keeping the increment/decrement logic
            cout << "\nTesting Reserve Sensors (++fuel): " << ++fuelLevel << "\n";
            cout << "Testing Buffer (fuel++): " << fuelLevel++ << "\n";
            cout << "Final Fuel Level: " << fuelLevel << "\n";
            break;

        case '5':
            cout << "\nDisconnecting from Ship Core...\n";
            cout << "Safe Travels, Captain!\n";
            break;

        default:
            cout << "\nCommand Not Recognized!\n";
        }

    } while (shipChoice != '5');

    return 0;
}