#include <iostream>
#include <fstream>
#include <string>
#include <algorithm>
using namespace std;

// Abstract Base Class for Person
class Person {
protected:
    string name;
    string cnic;

public:
    // Pure virtual function for displayInfo, making Person an abstract class
    virtual void displayInfo() const = 0;

    // Getter for CNIC
    string getCNIC() const { return cnic; }

    virtual ~Person() {} // Virtual Destructor
};

// Student class derived from Person (Single Inheritance)
class Student : public Person {
    string studentID;
    string degreeEnrolled;
    string subjects[3];
    string grades[3];  // Grades for each subject
    int subjectCount;
    int extracurricularPoints;  // Extra-curricular activity points
    int meritScore;  // Merit score based on grades and activities

public:
    Student() : subjectCount(0), extracurricularPoints(0), meritScore(0) {}

    // Parameterized Constructor
    Student(string id, string n, string c, string d, string sub1, string sub2, string sub3, string grd1, string grd2, string grd3, int ecPoints) {
        studentID = id;
        name = n;
        cnic = c;
        degreeEnrolled = d;
        subjects[0] = sub1;
        subjects[1] = sub2;
        subjects[2] = sub3;
        grades[0] = grd1;
        grades[1] = grd2;
        grades[2] = grd3;
        subjectCount = 3;
        extracurricularPoints = ecPoints;
        calculateMeritScore();
    }

    // Override displayInfo() from Person to display student-specific details
    void displayInfo() const override {
        cout << "\nStudent ID: " << studentID
            << "\nName: " << name
            << "\nCNIC: " << cnic
            << "\nDegree: " << degreeEnrolled
            << "\nSubjects: ";
        for (int i = 0; i < subjectCount; ++i)
            cout << subjects[i] << " ";
        cout << "\nGrades: ";
        for (int i = 0; i < subjectCount; ++i)
            cout << grades[i] << " ";
        cout << "\nMerit Score: " << meritScore << endl;
    }

    string getStudentID() const { return studentID; }
    int getMeritScore() const { return meritScore; }

    // Save student details to a file
    void saveToFile(ofstream& out) const {
        out << studentID << "," << name << "," << cnic << "," << degreeEnrolled;
        for (int i = 0; i < subjectCount; ++i)
        {
            out << "," << subjects[i]; 
        }
        for (int i = 0; i < subjectCount; ++i)
        {
            out << "," << grades[i];
        }
        out << "," << extracurricularPoints << "," << meritScore << endl;
    }

    // Load student details from a file (Static method)
    static Student loadFromFile(ifstream& in) {
        string id, n, c, d, s1, s2, s3, g1, g2, g3, ecPointsStr , merit;
        int ecPoints;
        if (!getline(in, id, ',')) return Student();
        if (!getline(in, n, ',')) return Student();
        if (!getline(in, c, ',')) return Student();
        if (!getline(in, d, ',')) return Student();
        if (!getline(in, s1, ',')) return Student();
        if (!getline(in, s2, ',')) return Student();
        if (!getline(in, s3, ',')) return Student();
        if (!getline(in, g1, ',')) return Student();
        if (!getline(in, g2, ',')) return Student();
        if (!getline(in, g3, ',')) return Student();
        if (!getline(in, ecPointsStr, ',')) return Student();
        if (!getline(in, merit)) return Student();

        try {
            ecPoints = stoi(ecPointsStr);
        }
        catch (...) {
            ecPoints = 0;
        }

        return Student(id, n, c, d, s1, s2, s3, g1, g2, g3, ecPoints);
    }

    // Calculate Merit Score based on grades and extracurricular points
    void calculateMeritScore() {
        int subjectPoints = subjectCount * 2;  // 2 points per subject
        int gradePoints = 0;

        // Grade-based points (A=5, B=4, C=3, D=2, F=0)
        for (int i = 0; i < subjectCount; ++i) {
            if (grades[i] == "A") gradePoints += 5;
            else if (grades[i] == "B") gradePoints += 4;
            else if (grades[i] == "C") gradePoints += 3;
            else if (grades[i] == "D") gradePoints += 2;
            else if (grades[i] == "F") gradePoints += 0;
        }

        // The total merit score
        meritScore = subjectPoints + gradePoints + extracurricularPoints;
    }
};

// Degree class for the Degree Programs
class Degree {
    string degreeName;
    int duration;
    string subjects[3];
    int subjectCount;

public:
    Degree() : subjectCount(0), duration(0) {}

    Degree(string name, int dur, string sub1, string sub2, string sub3) {
        degreeName = name;
        duration = dur;
        subjects[0] = sub1;
        subjects[1] = sub2;
        subjects[2] = sub3;
        subjectCount = 3;
    }

    // Display Degree Information
    void displayDegree() const {
        cout << "\nDegree: " << degreeName << "\nDuration: " << duration << " years\nSubjects: ";
        for (int i = 0; i < subjectCount; ++i)
            cout << subjects[i] << " ";
        cout << endl;
    }

    string getName() const { return degreeName; }

    // Save Degree details to a file
    void saveToFile(ofstream& out) const {
        out << degreeName << "," << duration << "," << subjects[0] << "," << subjects[1] << "," << subjects[2] << endl;
    }

    // Load Degree details from a file (Static method)
    static Degree loadFromFile(ifstream& in) {
        string name, s1, s2, s3, durStr;
        int dur;
        if (!getline(in, name, ',')) return Degree();
        if (!getline(in, durStr, ',')) return Degree();
        try {
            dur = stoi(durStr);
        }
        catch (...) {
            dur = 0;
        }
        if (!getline(in, s1, ',')) return Degree();
        if (!getline(in, s2, ',')) return Degree();
        if (!getline(in, s3)) return Degree();
        return Degree(name, dur, s1, s2, s3);
    }
};

// Function to generate merit list by sorting students based on merit score
void generateMeritList(Student students[], int count) {
    // Sorting students by merit score in descending order
    sort(students, students + count, [](const Student& a, const Student& b) {
        return a.getMeritScore() > b.getMeritScore();
        });

    cout << "\n--- Merit List ---\n";
    for (int i = 0; i < count; ++i) {
        cout << i + 1 << ". ";
        students[i].displayInfo(); // Display each student's info
    }
}

// Driver Code for College Admission System
int main() {
    Student students[100];  // Array to store students
    Degree degrees[10];  // Array to store degrees
    int studentCount = 0;
    int degreeCount = 0;
    int choice;

    // Load Degrees from file
    ifstream degIn("degrees.txt");
    while (degIn.peek() != EOF) {
        Degree d = Degree::loadFromFile(degIn);
        if (!d.getName().empty())
            degrees[degreeCount++] = d;
    }
    degIn.close();

    // Load Students from file
    ifstream stuIn("students.txt");
    while (stuIn.peek() != EOF) {
        Student s = Student::loadFromFile(stuIn);
        if (!s.getStudentID().empty())
            students[studentCount++] = s;
    }
    stuIn.close();

    do {
        cout << "\n--- College Admission Menu ---\n";
        cout << "1. Register New Student\n2. View All Students\n3. View Degree Programs\n4. Search Student by CNIC\n5. Generate Merit List\n6. Save Records to File\n7. Load Records from File\n0. Exit\nChoice: ";
        cin >> choice;
        cin.ignore();

        // Menu-driven options for student registration, viewing, and more
        if (choice == 1) {
            string id, name, cnic, degree;
            cout << "Enter Student ID: "; getline(cin, id);
            cout << "Enter Name: "; getline(cin, name);
            cout << "Enter CNIC: "; getline(cin, cnic);
            cout << "Enter Degree: "; getline(cin, degree);
            string sub1, sub2, sub3;
            cout << "Enter Subject 1: "; getline(cin, sub1);
            cout << "Enter Subject 2: "; getline(cin, sub2);
            cout << "Enter Subject 3: "; getline(cin, sub3);
            string grd1, grd2, grd3;
            cout << "Enter Grade for Subject 1: "; getline(cin, grd1);
            cout << "Enter Grade for Subject 2: "; getline(cin, grd2);
            cout << "Enter Grade for Subject 3: "; getline(cin, grd3);
            int ecPoints;
            cout << "Enter Extra-curricular Activity Points: "; cin >> ecPoints;
            students[studentCount++] = Student(id, name, cnic, degree, sub1, sub2, sub3, grd1, grd2, grd3, ecPoints);
        }
        else if (choice == 2) {
            for (int i = 0; i < studentCount; ++i)
                students[i].displayInfo(); // Display all students
        }
        else if (choice == 3) {
            for (int i = 0; i < degreeCount; ++i)
                degrees[i].displayDegree(); // Display all degrees
        }
        else if (choice == 4) {
            string searchCNIC;
            cout << "Enter CNIC to search: ";
            getline(cin, searchCNIC);
            bool found = false;
            for (int i = 0; i < studentCount; ++i) {
                if (students[i].getCNIC() == searchCNIC) {
                    students[i].displayInfo(); // Display student info by CNIC
                    found = true;
                    break;
                }
            }
            if (!found) cout << "Student not found.\n";
        }
        else if (choice == 5) {
            generateMeritList(students, studentCount); // Generate merit list
        }
        else if (choice == 6) {
            ofstream stuOut("students.txt");
            for (int i = 0; i < studentCount; ++i)
                students[i].saveToFile(stuOut); // Save student data to file
            stuOut.close();

            ofstream degOut("degrees.txt");
            for (int i = 0; i < degreeCount; ++i)
                degrees[i].saveToFile(degOut); // Save degree data to file
            degOut.close();

            cout << "Data saved successfully.\n";
        }
        else if (choice == 7) {
            studentCount = 0;
            ifstream stuInReload("students.txt");
            while (stuInReload.peek() != EOF) {
                students[studentCount++] = Student::loadFromFile(stuInReload);
            }
            stuInReload.close();

            degreeCount = 0;
            ifstream degInReload("degrees.txt");
            while (degInReload.peek() != EOF) {
                degrees[degreeCount++] = Degree::loadFromFile(degInReload);
            }
            degInReload.close();
            cout << "Records loaded successfully.\n";
        }

    } while (choice != 0); // Exit when choice is 0
    return 0;
}