//////////////////////////////////////////////////////////////////////////
////////                Question no 1      /////////////////////////////// 
//////////////////////////////////////////////////////////////////////////

#include<iostream>
using namespace std;

class bankaccount
{
private:
	string name;
	int accountno;
	float balance;
	static int accountcount;
public:
	bankaccount()
	{
		name = "";
		accountno = 0;
		balance = 0;
	}
	bankaccount(string n, int ac, float b)
	{
		name = n;
		accountno = ac;
		balance = b;
		accountcount++;
	}

	void setname(string n)
	{
		name = n;
	}

	void setaccountno(int ac)
	{
		accountno = ac;
	}

	void setbalance(float b)
	{
		balance = b;
	}
	string getname()const
	{
		return name;
	}
	int getaccountno()const
	{
		return accountno;
	}
	float getbalance()const
	{
		return balance;
	}
	static int getaccountcount()
	{
		return accountcount;
	}

	void deposit(float amount)
	{
		if (amount > 0)
		{
			balance += amount;
			cout << "Deposited: " << amount << " | New Balance: " << balance << endl;
		}
		else
		{
			cout << "Invalid deposit amount!" << endl;
		}
	}

	void withdraw(float amount)
	{
		if (amount > 0 && amount <= balance)
		{
			balance -= amount;
			cout << "Withdrawn: " << amount << " | New Balance: " << balance << endl;
		}
		else
		{
			cout << "Insufficient balance or invalid amount!" << endl;
		}
	}
	~bankaccount()
	{
		cout << "account has been closed  // object destroyed" << endl;
	}
	friend void transfer(bankaccount &b1, bankaccount &b2);
};

int bankaccount::accountcount = 0;

void transfer(bankaccount &b1, bankaccount &b2)
{
	float amount;
	cout << "enter the amount of money you want to transfer" << endl;
	cin >> amount;
	if (b1.balance >= amount)
	{
		b1.balance = b1.balance - amount;
		b2.balance = b2.balance + amount;
	}
	else
	{
		cout << "insuficient amount" << endl;
	}
}


int main()

{
	bankaccount acc1("John Doe", 101, 5000);
	bankaccount acc2("Jane Smith", 102, 3000);

	cout << "Initial Balances:" << endl;
	cout << acc1.getname() << " Balance: " << acc1.getbalance() << endl;
	cout << acc2.getname() << " Balance: " << acc2.getbalance() << endl;

	// Demonstrating deposit and withdraw
	acc1.deposit(1000);
	acc1.withdraw(2000);
	acc1.withdraw(5000); // Should display insufficient balance

	// Demonstrating transfer
	transfer(acc1, acc2);

	cout << "Final Balances:" << endl;
	cout << acc1.getname() << " Balance: " << acc1.getbalance() << endl;
	cout << acc2.getname() << " Balance: " << acc2.getbalance() << endl;

}

//////////////////////////////////////////////////////////////////////////
////////                Question no 2      /////////////////////////////// 
//////////////////////////////////////////////////////////////////////////


#include <iostream>
using namespace std;
class complex
{
private:
	double real;
	double imaginary;
public:
	complex()
	{
		real = 0;
		imaginary = 0;
	}
	complex(double r, double img)
	{
		real = r;
		imaginary = img;

	}
	///////////////////////////////////////////////////////////////////
	/////     arithmatic operator overload    ////////////////////
	/////////////////////////////////////////////////////////////

	complex operator+(const complex& c1)
	{
		complex temp;
		temp.real = real + c1.real;
		temp.imaginary = imaginary + c1.imaginary;
		return temp;
     }

	complex operator*(const complex& c1)
	{
		complex temp;
		temp.real = real * c1.real;
		temp.imaginary = imaginary * c1.imaginary;
		return temp;
	}

	complex operator-(const complex& c1)
	{
		complex temp;
		temp.real = real - c1.real;
		temp.imaginary = imaginary - c1.imaginary;
		return temp;
	}
	complex operator/(const complex& c)
	{
		complex temp;
		float den;
		den = ((c.real * c.real) + (c.imaginary * c.imaginary));
		temp.real = ((real * c.real) + (imaginary * c.imaginary)) / den;
		temp.imaginary = ((imaginary * c.real) - (real * c.imaginary)) / den;
		return temp;

	}

	///////////////////////////////////////////////////////////////////////
	///////////      relational operators         ///////////////
	////////////////////////////////////////////////////////////////

	double magnitude()const
	{
		double mag;
		mag= sqrt(real * real + imaginary * imaginary);
		return mag;
	}

	bool operator<(complex& c)
	{
		if (magnitude() < c.magnitude())
		{
			return true;
		}
		else
		{
			return false;
		}
	}

	bool operator>(complex& c)
	{
		if (magnitude() > c.magnitude())
		{
			return true;
		}
		else
		{
			return false;
		}
	}

	bool operator<=(complex& c)
	{
		if (magnitude() <= c.magnitude())
		{
			return true;
		}
		else
		{
			return false;
		}
	}

	bool operator>=(complex& c)
	{
		if (magnitude() >= c.magnitude())
		{
			return true;
		}
		else
		{
			return false;
		}
	}


	bool operator==(complex& c)
	{
		if (magnitude() == c.magnitude())
		{
			return true;
		}
		else
		{
			return false;
		}
	}


	bool operator!=(complex& c)
	{
		if (magnitude() != c.magnitude())
		{
			return true;
		}
		else
		{
			return false;
		}
	}
	//////////////////////////////////////////////////////////////
	//////////          assignment operator              /////////
	///////////////////////////////////////////////////////////

	complex& operator+=(const complex& c)
	{
		real += c.real;
		imaginary += c.imaginary;
		return *this;
	}
	complex& operator-=(const complex& c) 
	{
		real -= c.real;
		imaginary -= c.imaginary;
		return *this;
	}
	complex& operator*=(const complex& c)
	{
		real *= c.real;
		imaginary *= c.imaginary;
		return *this;
	}


	/////////////////////////////////////////////////////
	////         subscript operator //////////////
	/////////////////////////////////////////////

	double operator[](int index) const 
	{
		if (index == 0)
		{
			return real;
		}
		else if (index == 1)
		{
			return imaginary;
		}
		else
		{
			cout << "invalid index" << endl;
		}
			
	}

	double operator()() const 
	{
		return magnitude();
	}
	
	friend istream& operator>>(istream& in, complex& c);
	friend ostream& operator<<(ostream& out, const complex& c);

};

//////////////////////////////////////////////////////////
//////       input and output stream operator    ///////////////
///////////////////////////////////////////////////////////

ostream& operator<<(ostream& out, const complex& c)
{
	out<< "Complex Number: " << endl;
	out << c.real << "+" << c.imaginary << "i" << endl;
	return out;
}

istream& operator>>(istream& in, complex& c)
{
	cout << "Enter real part: ";
	in >> c.real;
	cout << "Enter imaginary part: ";
	in >> c.imaginary;
	return in;
}


int main() {
	complex c1(3, 4), c2(1, -2);

	cout << "Complex Numbers:" << endl;
	cout << "c1 = " << c1 << endl;
	cout << "c2 = " << c2 << endl;

	// Demonstrate Arithmetic Operations
	cout << "c1 + c2 = " << (c1 + c2) << endl;
	cout << "c1 - c2 = " << (c1 - c2) << endl;
	cout << "c1 * c2 = " << (c1 * c2) << endl;
	cout << "c1 / c2 = " << (c1 / c2) << endl;

	// Demonstrate Compound Assignment Operators
	c1 += c2;
	cout << "After c1 += c2, c1 = " << c1 << endl;

	// Demonstrate Relational Operators
	cout << "c1 > c2: " << (c1 > c2) << endl;

	// Demonstrate Subscript Operator
	cout << "Real part of c1: " << c1[0] << endl;
	cout << "Imaginary part of c1: " << c1[1] << endl;

	// Demonstrate Function Call Operator
	cout << "Magnitude of c1: " << c1() << endl;

	return 0;
}




//////////////////////////////////////////////////////////////////////////
////////                Question no 3      /////////////////////////////// 
//////////////////////////////////////////////////////////////////////////


#include <iostream>
#include <string>
using namespace std;

class StudentRecord {
private:
    int studentID;
    string name;
    float GPA;
    static int studentCount; 

public:
    StudentRecord()
    {
        studentID = 0;
        name = "";
        GPA = 0;
        studentCount++;
        
    }
    StudentRecord(int id , string n , float g) 
    {
        studentID = id;
        name = n;
        GPA = g;
        studentCount++; 
    }

  
    ~StudentRecord()
    {
        studentCount--; 
    }

  
    void setStudentID(int id) 
    {
        studentID = id;
    }
    void setName(string n)
    {
        name = n; 
    }
    void setGPA(float g)
    {
        if (g <= 4)
        {
            GPA = g;
        }
        else
        {
            cout << "invalid gpa"<<endl;

        }
      
    }

    int getStudentID() const 
    {
        return studentID;
    }
    string getName() const 
    {
        return name;
    }
    float getGPA() const 
    {
        return GPA;
    }

    // Display function to print student details
    void displayStudent() const 
    {
        cout << "ID: " << studentID << ", Name: " << name << ", GPA: " << GPA << endl;
    }

    // Static function to display total students
    static void displayTotalStudents()
    {
        cout << "Total students: " << studentCount << endl;
    }
};

// Initializing static member variable
int StudentRecord::studentCount = 0;

int main()
{
    StudentRecord students[5]; // Array of objects

    // Taking input from the user
    for (int i = 0; i < 5; i++) {
        int id;
        string name;
        float gpa;

        cout << "Enter details for student " << i + 1 << endl;
        cout << "Enter Student ID: ";
        cin >> id;
        cout << "Enter GPA: ";
        cin >> gpa;
        cout << "Enter Name: ";
        cin >> name;


        students[i].setStudentID(id);
        students[i].setName(name);
        students[i].setName(name);
        students[i].setGPA(gpa);
    }

    // Display all student records
    cout << "--- Student Records ---"<<endl;
    for (int i = 0; i < 5; i++) {
        students[i].displayStudent();
    }

    // Display total student count
    StudentRecord::displayTotalStudents();

    cout << endl;
    cout << "--- Memory Diagram ---" << endl;
    for (int i = 0; i < 5; i++) {
        cout << "**************************"<<endl;
        cout << "*  Student Object [" << i << "]  *"<<endl;
        cout << "**************************"<<endl;
        cout << "*  ID   : " << students[i].getStudentID() << "  *"<<endl;
        cout << "*  Name : " << students[i].getName() << "  *"<<endl;
        cout << "*  GPA  : " << students[i].getGPA() << "  *"<<endl;
        cout << "**************************"<<endl;
    }

    return 0;
}