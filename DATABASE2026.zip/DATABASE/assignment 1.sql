-- =========================
-- DATABASE CREATION
-- =========================
CREATE DATABASE RetailDB;
USE RetailDB;

-- =========================
-- TABLES
-- =========================

CREATE TABLE Customers (
    customer_id INT PRIMARY KEY,
    customer_name VARCHAR(100) NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    city VARCHAR(50),
    gender CHAR(1),
    registration_date DATE DEFAULT CURRENT_DATE,
    CHECK (gender IN ('M','F') OR gender IS NULL)
);

CREATE TABLE Suppliers (
    supplier_id INT PRIMARY KEY,
    supplier_name VARCHAR(100) NOT NULL,
    contact_email VARCHAR(100) UNIQUE,
    city VARCHAR(50),
    phone_number VARCHAR(20),
    registration_date DATE DEFAULT CURRENT_DATE
);

CREATE TABLE Products (
    product_id INT PRIMARY KEY,
    product_name VARCHAR(100) NOT NULL,
    category VARCHAR(50) NOT NULL,
    price DECIMAL(10,2) NOT NULL CHECK (price >= 0),
    stock_quantity INT DEFAULT 0 CHECK (stock_quantity >= 0),
    is_active BOOLEAN DEFAULT TRUE,
    supplier_id INT,
    FOREIGN KEY (supplier_id) REFERENCES Suppliers(supplier_id)
);

CREATE TABLE Sales (
    sale_id INT PRIMARY KEY,
    customer_id INT NOT NULL,
    product_id INT NOT NULL,
    quantity INT NOT NULL CHECK (quantity > 0),
    sale_date DATE DEFAULT CURRENT_DATE,
    FOREIGN KEY (customer_id) REFERENCES Customers(customer_id),
    FOREIGN KEY (product_id) REFERENCES Products(product_id)
);

-- =========================
-- INSERT DATA (UNIQUE)
-- =========================

-- Customers (15 rows)
INSERT INTO Customers VALUES
(1,'Ali Khan','ali1@gmail.com','Lahore','M','2025-01-10'),
(2,'Sara Ahmed','sara2@gmail.com','Karachi','F','2025-02-15'),
(3,'Usman Tariq','usman3@gmail.com','Islamabad','M','2025-03-05'),
(4,'Ayesha Noor','ayesha4@gmail.com','Lahore','F','2025-01-20'),
(5,'Bilal Shah','bilal5@gmail.com','Multan','M','2025-02-10'),
(6,'Hina Malik','hina6@gmail.com','Faisalabad','F','2025-01-25'),
(7,'Zain Ali','zain7@gmail.com','Rawalpindi','M','2025-02-12'),
(8,'Fatima Noor','fatima8@gmail.com','Karachi','F','2025-02-28'),
(9,'Ahmed Raza','ahmed9@gmail.com','Lahore','M','2025-03-01'),
(10,'Iqra Khan','iqra10@gmail.com','Multan','F','2025-01-18'),
(11,'Hamza Jutt','hamza11@gmail.com','Sialkot','M','2025-02-22'),
(12,'Noor Ali','noor12@gmail.com','Lahore','F','2025-02-05'),
(13,'Danish Khan','danish13@gmail.com','Islamabad','M','2025-01-30'),
(14,'Maham Tariq','maham14@gmail.com','Karachi','F','2025-02-11'),
(15,'Saad Ahmed','saad15@gmail.com','Peshawar','M','2025-02-25');

-- Suppliers
INSERT INTO Suppliers VALUES
(1,'TechSource','tech@gmail.com','Lahore','03001234567','2025-01-01'),
(2,'FashionHub','fashion@gmail.com','Karachi','03007654321','2025-01-05'),
(3,'GroceryWorld','grocery@gmail.com','Multan','03009998888','2025-01-07');

-- Products (15 rows)
INSERT INTO Products VALUES
(1,'Laptop','Electronics',120000,10,1,1),
(2,'Mobile','Electronics',50000,20,1,1),
(3,'Headphones','Electronics',3000,25,1,1),
(4,'Shirt','Clothing',2000,30,1,2),
(5,'Shoes','Clothing',4000,15,1,2),
(6,'Jeans','Clothing',3500,18,1,2),
(7,'Rice Bag','Grocery',3000,25,1,3),
(8,'Flour','Grocery',2000,40,1,3),
(9,'Sugar','Grocery',1500,35,1,3),
(10,'Tablet','Electronics',60000,12,1,1),
(11,'Jacket','Clothing',5000,8,1,2),
(12,'Milk Pack','Grocery',300,50,1,3),
(13,'Smart Watch','Electronics',15000,10,1,1),
(14,'T-shirt','Clothing',1200,22,1,2),
(15,'Cooking Oil','Grocery',4500,28,1,3);

-- Sales (15 rows)
INSERT INTO Sales VALUES
(1,1,1,2,'2025-01-15'),
(2,2,2,1,'2025-02-10'),
(3,3,3,3,'2025-02-12'),
(4,4,4,2,'2025-02-18'),
(5,5,5,4,'2025-02-20'),
(6,6,6,2,'2025-02-05'),
(7,7,7,3,'2025-01-22'),
(8,8,8,2,'2025-02-14'),
(9,9,9,1,'2025-02-16'),
(10,10,10,2,'2025-01-30'),
(11,11,11,3,'2025-02-25'),
(12,12,12,5,'2025-02-28'),
(13,13,13,2,'2025-02-03'),
(14,14,14,4,'2025-02-09'),
(15,15,15,3,'2025-02-27');

-- =========================
-- QUERIES (Q1–Q12)
-- =========================

-- Q1
SELECT DISTINCT city, gender
FROM Customers
ORDER BY city, gender;

-- Q2
SELECT product_name, price,
       price * 0.9 AS discounted_price
FROM Products
WHERE is_active = 1 AND price > 1000
ORDER BY discounted_price DESC;

-- Q3
SELECT *
FROM Sales
WHERE quantity > 1
AND DAYOFWEEK(sale_date) BETWEEN 2 AND 4
ORDER BY sale_date DESC, quantity ASC;

-- Q4
SELECT category,
       COUNT(*) AS total_products,
       SUM(stock_quantity) AS total_stock
FROM Products
GROUP BY category
HAVING COUNT(*) > 2
ORDER BY total_products DESC;

-- Q5
SELECT category,
       AVG(price) AS avg_price,
       MAX(price) AS max_price
FROM Products
GROUP BY category
HAVING AVG(price) > 1000
ORDER BY avg_price DESC;

-- Q6
SELECT customer_id,
       SUM(quantity) AS total_quantity,
       COUNT(*) AS orders
FROM Sales
WHERE quantity > 0
GROUP BY customer_id
ORDER BY total_quantity DESC;

-- Q7
SELECT category,
       MIN(price) AS min_price,
       MAX(price) AS max_price,
       AVG(price) AS avg_price
FROM Products
GROUP BY category
HAVING MIN(price) < 5000
ORDER BY avg_price DESC;

-- Q8
SELECT product_id,
       SUM(quantity) AS total_quantity,
       COUNT(DISTINCT customer_id) AS unique_customers
FROM Sales
GROUP BY product_id
HAVING SUM(quantity) > 2
ORDER BY total_quantity DESC;

-- Q9
SELECT product_id,
       SUM(quantity) AS total_units,
       AVG(quantity) AS avg_quantity
FROM Sales
GROUP BY product_id
HAVING SUM(quantity) > 1
ORDER BY total_units DESC, avg_quantity ASC;

-- Q10
SELECT *
FROM Sales
WHERE quantity > 1
AND sale_date BETWEEN '2025-01-01' AND '2025-03-01'
AND MOD(sale_id,2) = 0
ORDER BY sale_date DESC, quantity ASC;

-- Q11
SELECT category,
       SUM(stock_quantity) AS total_stock,
       COUNT(*) AS total_products
FROM Products
GROUP BY category
HAVING SUM(stock_quantity) > 20
ORDER BY total_stock DESC;

-- Q12
SELECT 
    CONCAT(UPPER(LEFT(customer_name,1)),
    LOWER(SUBSTRING(customer_name,2))) AS formatted_name,
    DATE_FORMAT(registration_date,'%b-%Y') AS reg_month_year
FROM Customers
WHERE registration_date < CURDATE()
ORDER BY registration_date DESC;