-- case study 1

USE financelab; 

WITH transactionhistory as ( 

SELECT  a.account_id,a.customer_id,a.opening_balance, 

Count(t.transaction_id) as total_transactions, 

MAX(t.transaction_date) as latest_transaction 

from accounts a 

LEFT JOIN transactions t on t.account_id=a.account_id 

group by a.account_id,a.customer_id,a.opening_balance 

), 

same_accounts as( 

SELECT a1.account_id as account1, 

a2.account_id as account2 

,a1.opening_balance 

from accounts a1 

inner join accounts a2 on a1.account_id!=a2.account_id AND  

a1.opening_balance=a2.opening_balance 

) 

SELECT c.customer_name, a.account_id,ts.total_transactions,ts.opening_balance,ts.latest_transaction, 

case when ts.opening_balance>100000 and ts.total_transactions=0 

then 'high value silent' 

WHEN ts.total_transactions<2 then 'low activity' 

WHEN ts.latest_transaction<curdate()-INTERVAL 180 DAY then 'inactive' 

ELSE 'NORMAL' 

END AS ACCOUNT_FLAG 

FROM customers c 

inner join accounts a on a.customer_id=c.customer_id 

LEFT JOIN transactionhistory ts  on ts.account_id=a.account_id 

-- case study 2

WITH TransactionSummary AS ( SELECT a.customer_id,COUNT(t.transaction_id) AS total_transactions 

FROM Accounts a LEFT JOIN Transactions t   ON a.account_id = t.account_id 

GROUP BY a.customer_id 

), 

samebehaviour AS ( 

SELECT ts1.customer_id, ts2.customer_id AS similar_customer FROM TransactionSummary ts1 

INNER JOIN TransactionSummary ts2 ON ts1.customer_id <> ts2.customer_id AND ts2.total_transactions BETWEEN ts1.total_transactions - 1  

AND ts1.total_transactions + 1 

) 

SELECT c.customer_id,c.customer_name,c.city,c.segment,ts.total_transactions,bs.similar_customer, 

CASE WHEN ts.total_transactions >= 3 THEN 'Highly Active' 

WHEN ts.total_transactions >= 1 THEN 'Moderately Active' 

WHEN ts.total_transactions IS NULL THEN 'Inactive' 

ELSE 'Low Activity'END AS Customer_Behavior 

FROM Customers c 

LEFT JOIN TransactionSummary ts ON c.customer_id = ts.customer_id 

RIGHT JOIN samebehaviour bs ON c.customer_id = bs.customer_id; 