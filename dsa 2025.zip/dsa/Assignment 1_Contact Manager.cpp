#include <iostream>
#include <fstream>
#include <cctype>
#include <string>
using namespace std;

const int MAX_ITEMS = 50;
enum RelationType { LESS, GREATER, EQUAL };

///////  Title Validation  ///////////
static bool check_title(string& word) {
    if (word.empty()) return false;
    for (int i = 0; i < word.length(); i++) {
        // Allowing letters and spaces for titles
        if (!isalpha(word[i]) && word[i] != ' ') return false;
        word[i] = tolower(word[i]);
    }
    return true;
}

//////  ISBN Validation (13 Digits)  ////////////
static bool check_isbn(string& isbn) {
    if (isbn.size() != 13) return false;
    for (int i = 0; i < isbn.length(); i++) {
        if (!isdigit(isbn[i])) return false;
    }
    return true;
}

//////  Author Validation  ////////////
static bool check_author(string& auth) {
    if (auth.empty() || auth.size() > 50) return false;
    return true;
}

class BookType {
public:
    BookType() {
        isbn = "";
        title = "";
        author = "";
        isValid = false; 
    }

    string getTitle() const { return title; }
    string getISBN() const { return isbn; }
    string getAuthor() const { return author; }
    bool getIsValid() const { return isValid; } 

    RelationType ComparedTo(BookType otherBook) const {
        if (title < otherBook.title)
            return LESS;
        else if (title > otherBook.title)
            return GREATER;
        else
            return EQUAL;
    }

    void Print(ofstream& out) const {
        out << title << "|" << isbn << "|" << author << endl;
    }

    bool Initialize(string t, string a, string i) {
        if (check_title(t) && check_isbn(i) && check_author(a)) {
            title = t;
            isbn = i;
            author = a;
            isValid = true;
            return true;
        } else {
            cout << "Invalid book data. Process failed." << endl;
            isValid = false;
            return false;
        }
    }

private:
    string isbn;
    string title;
    string author;
    bool isValid; 
};

class SortedLibrary {
public:
    SortedLibrary() { length = 0; }
    void MakeEmpty() { length = 0; }
    bool IsFull() const { return (length == MAX_ITEMS); }
    int GetLength() const { return length; }
    
    BookType RetrieveBook(BookType& item, bool& found);
    int search(BookType& item, bool& found);
    void InsertBook(BookType& item);
    void DeleteBook(BookType& item);
    
    void ResetList() { currentPos = -1; }
    bool GetNextBook(BookType& item);

private:
    int length;
    BookType info[MAX_ITEMS];
    int currentPos = 0;
};

void SortedLibrary::InsertBook(BookType& item) {
    if (!item.getIsValid()) return;
    if (length >= MAX_ITEMS) return;

    bool found;
    search(item, found);
    if (found) {
        cout << "Book already exists in archive." << endl;
        return;
    }

    int location = 0;
    while (location < length && item.ComparedTo(info[location]) == GREATER) {
        location++;
    }

    for (int i = length; i > location; i--) {
        info[i] = info[i - 1];
    }

    info[location] = item;
    length++;
    cout << "Book archived successfully." << endl; 
}

int SortedLibrary::search(BookType& item, bool& found) {
    if (!item.getIsValid()) { found = false; return -1; }

    int location = 0;
    found = false;
    while (location < length && !found) {
        switch (item.ComparedTo(info[location])) {
            case LESS: return -1; 
            case EQUAL: found = true; return location;
            case GREATER: location++; break;
        }
    }
    return -1;
}

void SortedLibrary::DeleteBook(BookType& item) {
    bool found = false;
    int location = search(item, found);
    if (found) {
        for (int i = location; i < length - 1; i++) {
            info[i] = info[i + 1];
        }
        length--;
        cout << "Book removed from archive." << endl;
    } else {
        cout << "Book not found." << endl;
    }
}

bool SortedLibrary::GetNextBook(BookType& item) {
    if (currentPos < length - 1) {
        currentPos++;
        item = info[currentPos];
        return true;
    }
    return false;
}

int main() {
    SortedLibrary myLib;
    int choice;
    string title, isbn, author;

    do {
        cout << "\n--- LIBRARY SYSTEM ---\n";
        cout << "1. Add Book\n2. Remove Book\n3. Find Book\n4. List All\n5. Save\n6. Load\n10. Exit\n";
        cout << "Selection: ";
        
        if (!(cin >> choice)) {
            cin.clear(); cin.ignore(1000, '\n'); continue;
        }
        cin.ignore(1000, '\n'); 

        if (choice == 1) {
            cout << "Enter Title: "; getline(cin, title);
            cout << "Enter Author: "; getline(cin, author);
            cout << "Enter ISBN (13 digits): "; getline(cin, isbn);
            BookType book;
            if (book.Initialize(title, author, isbn)) myLib.InsertBook(book);
        }
        else if (choice == 2) {
            cout << "Enter Title to Delete: "; getline(cin, title);
            BookType book;
            if (book.Initialize(title, "temp", "0000000000000")) myLib.DeleteBook(book);
        }
        else if (choice == 4) {
            myLib.ResetList();
            BookType book;
            while (myLib.GetNextBook(book)) {
                cout << "Title: " << book.getTitle() << " | Author: " << book.getAuthor() << " | ISBN: " << book.getISBN() << endl;
            }
        }
        else if (choice == 5) {
            ofstream outFile("library.txt");
            myLib.ResetList(); BookType book;
            while (myLib.GetNextBook(book)) book.Print(outFile);
            outFile.close();
            cout << "Archive Saved.\n";
        }
        // ... (Other cases follow the same logic as your original code)

    } while (choice != 10);

    return 0;
}