#include <iostream>
#include <fstream>
#include <cctype> 
#include <string>
using namespace std;

const int MAX_ITEMS = 50;
enum RelationType { LESS, GREATER, EQUAL };

class ItemType {
public:
    ItemType() { value = ' '; }

    RelationType ComparedTo(ItemType otherItem) const {
        if (value < otherItem.value) return LESS;
        else if (value > otherItem.value) return GREATER;
        else return EQUAL;
    }

    void Print(ofstream& out) const { out << value << " "; }

    void Initialize(char letter) { value = letter; }
    char GetValue() const { return value; }

private:
    int value; 
};

class FullStack {};
class EmptyStack {};

class StackType {
private:
    int top;
    ItemType items[MAX_ITEMS];
public:
    StackType() { top = -1; }
    ItemType Top() {
        if (IsEmpty()) throw EmptyStack();
        return items[top];
    }
    bool IsEmpty() const { return(top == -1); }
    bool IsFull() const { return (top == MAX_ITEMS - 1); }
    void Push(ItemType newItem) {
        if (IsFull()) throw FullStack();
        top++;
        items[top] = newItem;
    }
    void Pop() {
        if (IsEmpty()) throw EmptyStack();
        top--;
    }
};

// Determines how symbols "float" to the end or start of phrases
int getSymbolWeight(char s) {
    if (s == '!' || s == '?') return 1;
    if (s == '#' || s == '$' || s == '%') return 2;
    if (s == '*') return 3;
    return 0;
}

bool isDecorativeSymbol(char c) {
    return (c == '!' || c == '?' || c == '#' || c == '$' || c == '%' || c == '*');
}

string reverseString(const string& s) {
    string temp;
    int n = s.length();
    for (int i = n - 1; i >= 0; i--) {
        temp += s[i];
    }
    return temp;
}

// Logic: Reorders text so symbols appear after the text in brackets
string applyFocusStyle(const string& text) {
    StackType st;
    string output;

    for (int i = 0; i < text.length(); ++i) {
        char c = text[i];
        if (isalnum(c)) {
            output += c; 
        }
        else if (c == '(') {
            ItemType item; item.Initialize(c);
            st.Push(item);
        }
        else if (c == ')') {
            while (!st.IsEmpty() && st.Top().GetValue() != '(') {
                output += st.Top().GetValue();
                st.Pop();
            }
            if (!st.IsEmpty()) st.Pop(); 
        }
        else if (isDecorativeSymbol(c)) {
            while (!st.IsEmpty() && getSymbolWeight(st.Top().GetValue()) >= getSymbolWeight(c)) {
                output += st.Top().GetValue();
                st.Pop();
            }
            ItemType item; item.Initialize(c);
            st.Push(item);
        }
    }
    while (!st.IsEmpty()) {
        output += st.Top().GetValue();
        st.Pop();
    }
    return output;
}

// Logic: Reorders text so symbols appear before the text in brackets
string applyHeaderStyle(const string& text) {
    string rev = reverseString(text);
    for (int i = 0; i < (int)rev.length(); i++) {
        if (rev[i] == '(') rev[i] = ')';
        else if (rev[i] == ')') rev[i] = '(';
    }
    string temp = applyFocusStyle(rev);
    return reverseString(temp);
}

int main() {
    cout << "================ TEXT FRAME PROCESSOR ================\n";

    while (true) {
        cout << "\nMenu:\n";
        cout << "  1. Process Text Phrase\n";
        cout << "  2. Exit\n";
        cout << "Select: ";

        int choice;
        cin >> choice;
        cin.ignore();

        if (choice == 1) {
            string input;
            cout << "\nEnter text (use brackets and symbols e.g. (Hello#*)): ";
            getline(cin, input);

            cout << "\nStyle Options:\n";
            cout << "  1. Tail-Style (Symbols at end)\n";
            cout << "  2. Head-Style (Symbols at start)\n";
            cout << "Selection: ";

            int style;
            cin >> style;
            cin.ignore();

            try {
                if (style == 1)
                    cout << "Result: " << applyFocusStyle(input) << "\n";
                else if (style == 2)
                    cout << "Result: " << applyHeaderStyle(input) << "\n";
                else
                    cout << "Invalid style.\n";
            }
            catch (...) {
                cerr << "Processing Error: Check bracket nesting.\n";
            }
        } 
        else if (choice == 2) {
            break;
        }
    }
    return 0;
}