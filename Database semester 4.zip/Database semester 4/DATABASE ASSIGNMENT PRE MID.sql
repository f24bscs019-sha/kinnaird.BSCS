DROP DATABASE IF EXISTS RetailDB;
CREATE DATABASE RetailDB;
USE RetailDB;



CREATE TABLE Customers (
    customer_id INT PRIMARY KEY NOT NULL,
    customer_name VARCHAR(100) NOT NULL,
    email VARCHAR(255) UNIQUE NOT NULL,
    city VARCHAR(100) NULL,
    gender CHAR(1) NULL CHECK (gender IN ('M','F')),
    registration_date DATE NOT NULL DEFAULT (CURRENT_DATE)
);

CREATE TABLE Suppliers (
    supplier_id INT PRIMARY KEY NOT NULL,
    supplier_name VARCHAR(250) NOT NULL,
    contact_email VARCHAR(250) UNIQUE,
    city VARCHAR(250),
    phone_number VARCHAR(15),
    registration_date DATE NOT NULL DEFAULT (CURRENT_DATE)
);

CREATE TABLE Products (
    product_id INT PRIMARY KEY NOT NULL,
    product_name VARCHAR(100) NOT NULL,
    category VARCHAR(50) NOT NULL,
    price DECIMAL(10,2) NOT NULL CHECK (price >= 0),
    stock_quantity INT NOT NULL DEFAULT 0 CHECK (stock_quantity >= 0),
    is_active TINYINT DEFAULT 1,
    supplier_id INT,
    FOREIGN KEY (supplier_id) REFERENCES Suppliers(supplier_id)
);

CREATE TABLE Sales (
    sale_id INT PRIMARY KEY NOT NULL,
    customer_id INT NOT NULL,
    product_id INT NOT NULL,
    quantity INT NOT NULL CHECK (quantity > 0),
    sale_date DATE NOT NULL DEFAULT (CURRENT_DATE),
    FOREIGN KEY (customer_id) REFERENCES Customers(customer_id),
    FOREIGN KEY (product_id) REFERENCES Products(product_id)
);



INSERT INTO Customers VALUES
(1,  'Ahmed Khan',      'ahmed.khan@gmail.com',        'Basipur',   'M', '2025-11-01'),
(2,  'Sajid Khan',      'sajid.khan@gmail.com',        'Hujra',     'M', '2024-12-05'),
(3,  'Ahmed Ali',       'ali.ahmed@gmail.com',         'Lahore',    'M', '2025-02-28'),
(4,  'Ayesha Malik',    'ayesha.malik@gmail.com',      'Phol Nagar','M', '2025-02-15'),
(5,  'Usman Tariq',     'usman.tariq@hotmail.com',     'Arifwala',  'M', '2024-01-12'),
(6,  'Noor Ul Aina',    'noor.aina@gmail.com',         'Okara',     'F', '2023-01-22'),
(7,  'Kashif Ali',      'kashif.ali@gmail.com',        'Karachi',   'M', '2022-01-25'),
(8,  'Allama Iqbal',    'allama.iqbal@gmail.com',      'Lahore',    'M', '2025-02-01'),
(9,  'Zulkarneen',      'zulkarneen.abideen@gmail.com','Quetta',    'M', '2020-02-04'),
(10, 'Tahreem Zahra',   'tahreem.zahra@gmail.com',     'Islamabad', 'F', '2021-02-08'),
(11, 'Uzma Mirza',      'uzma.mirza@gmail.com',        'Faisalabad','F', '2025-02-10'),
(12, 'Noureen Fatima',  'noreen.fatima@gmail.com',     'Karachi',   'F', '2025-02-12'),
(13, 'Jameel Khan',     'jameel.jamsheed@gmail.com',   'Kashmir',   'M', '2025-02-14'),
(14, 'Aima Baig',       'aima.baig@gmail.com',         'Hunza',     'F', '2025-02-22'),
(15, 'Hasan Hussain',   'hasan.hussain@gmail.com',     'Kohat',     'M', '2025-02-20');


INSERT INTO Suppliers VALUES
(1,  'Hafeez Centre Electronics', 'hafeez.centre@supplier.pk',   'Lahore',    '03001112233', '2022-03-10'),
(2,  'Zainab Market Traders',     'zainab.market@supplier.pk',   'Karachi',   '03012223344', '2022-05-15'),
(3,  'Islamabad Mandi Traders',   'isb.mandi@supplier.pk',       'Islamabad', '03023334455', '2022-07-01'),
(4,  'Anarkali Cloth House',      'anarkali.cloth@supplier.pk',  'Lahore',    '03034445566', '2022-09-20'),
(5,  'Saddar Electronics Depot',  'saddar.elec@supplier.pk',     'Karachi',   '03045556677', '2023-01-05'),
(6,  'Sasta Bazaar Wholesale',    'sasta.bazaar@supplier.pk',    'Faisalabad','03056667788', '2023-03-18'),
(7,  'Kashmir Dry Fruits Co',     'kashmir.dryfruits@supplier.pk','Muzaffarabad','03067778899','2023-05-22'),
(8,  'Okara Agri Supplies',       'okara.agri@supplier.pk',      'Okara',     '03078889900', '2023-07-11'),
(9,  'Quetta Balochi Crafts',     'quetta.crafts@supplier.pk',   'Quetta',    '03089990011', '2023-09-01'),
(10, 'Hunza Organic Traders',     'hunza.organic@supplier.pk',   'Hunza',     '03090001122', '2023-10-15'),
(11, 'Kohat Textile Mills',       'kohat.textile@supplier.pk',   'Kohat',     '03101112233', '2024-01-08'),
(12, 'Arifwala Sports Goods',     'arifwala.sports@supplier.pk', 'Arifwala',  '03112223344', '2024-02-20'),
(13, 'Hujra Shah Khaas Traders',  'hujra.traders@supplier.pk',   'Hujra',     '03123334455', '2024-04-05'),
(14, 'Phool Nagar Farm Supplies', 'pnagar.farm@supplier.pk',     'Phol Nagar','03134445566', '2024-06-12'),
(15, 'Basipur General Store',     'basipur.general@supplier.pk', 'Basipur',   '03145556677', '2024-08-01');


INSERT INTO Products VALUES
(1,  'Dawlance Refrigerator',    'Electronics', 95000.00,  8,   1, 1),
(2,  'Haier Split AC 1.5 Ton',   'Electronics', 135000.00, 5,   1, 5),
(3,  'Orient LED TV 43 inch',    'Electronics', 72000.00,  10,  1, 1),
(4,  'Kenwood Microwave',        'Electronics', 18500.00,  15,  1, 5),
(5,  'Khaddar Shalwar Kameez',   'Clothing',    2800.00,   60,  1, 4),
(6,  'Lawn Printed Suit',        'Clothing',    3500.00,   50,  1, 11),
(7,  'Kohat Woolen Shawl',       'Clothing',    4200.00,   30,  1, 11),
(8,  'Leather Chappal Peshawari','Clothing',    1800.00,   45,  1, 4),
(9,  'Basmati Rice Kainat 5kg',  'Grocery',     1100.00,   120, 1, 8),
(10, 'Sufi Cooking Oil 5L',      'Grocery',     1650.00,   90,  1, 6),
(11, 'Tapal Danedar Tea 500g',   'Grocery',     850.00,    150, 1, 6),
(12, 'Hunza Dry Apricots 1kg',   'Grocery',     1200.00,   70,  1, 10),
(13, 'Charpai Wooden Bed',       'Furniture',   15000.00,  10,  1, 9),
(14, 'Sheesham Wood Sofa Set',   'Furniture',   65000.00,  4,   1, 13),
(15, 'Steel Almirah Local',      'Furniture',   28000.00,  7,   1, 9),
(16, 'Tape Ball Cricket Set',    'Sports',      3500.00,   35,  1, 12),
(17, 'Kabaddi Gear Set',         'Sports',      2200.00,   20,  1, 12),
(18, 'Badminton Racket Local',   'Sports',      1500.00,   40,  0, 12);


INSERT INTO Sales VALUES
(1,  1,  1,  1, '2025-01-06'),
(2,  2,  5,  3, '2025-01-07'),
(3,  3,  9,  2, '2025-01-08'),
(4,  4,  2,  1, '2025-01-13'),
(5,  5,  6,  2, '2025-01-14'),
(6,  6,  3,  1, '2025-01-15'),
(7,  7,  10, 4, '2025-01-20'),
(8,  8,  7,  2, '2025-01-21'),
(9,  9,  13, 1, '2025-01-22'),
(10, 10, 4,  3, '2025-01-25'),
(11, 11, 16, 2, '2025-01-27'),
(12, 12, 11, 5, '2025-01-28'),
(13, 13, 17, 1, '2025-02-03'),
(14, 14, 8,  2, '2025-02-04'),
(15, 15, 14, 1, '2025-02-05'),
(16, 1,  12, 3, '2025-02-10'),
(17, 2,  6,  2, '2025-02-11'),
(18, 3,  15, 1, '2025-02-12'),
(19, 4,  5,  4, '2025-02-17'),
(20, 5,  3,  2, '2025-02-18');

SELECT * FROM Customers;
SELECT * FROM Suppliers;
SELECT * FROM Products;
SELECT * FROM Sales;


-- 
-- Q1. Distinct Customer Cities with Gender
-- 
SELECT DISTINCT city, gender
FROM Customers
WHERE city IS NOT NULL
ORDER BY city, gender;

-- 
-- Q2. Active Products with 10% Discount (price > 1000)
-- 
SELECT product_name,
       price AS original_price,
       ROUND(price * 0.90, 2) AS discounted_price
FROM Products
WHERE is_active = 1 AND price > 1000
ORDER BY discounted_price DESC;


-- Q3. Sales on Mon/Tue/Wed where quantity > 1
-- DAYOFWEEK: 2=Monday 3=Tuesday 4=Wednesday

SELECT *,
       DAYNAME(sale_date) AS day_name
FROM Sales
WHERE quantity > 1
  AND DAYOFWEEK(sale_date) IN (2, 3, 4)
ORDER BY sale_date DESC, quantity ASC;

-- Q4. Total Products and Stock per Category
-- Only categories with more than 2 products

SELECT category,
       COUNT(product_id)   AS total_products,
       SUM(stock_quantity) AS total_stock
FROM Products
GROUP BY category
HAVING COUNT(product_id) > 2
ORDER BY total_products DESC;

-- Q5. Avg and Max Price where avg > 1000
SELECT category,
       ROUND(AVG(price), 2) AS avg_price,
       MAX(price)           AS max_price
FROM Products
GROUP BY category
HAVING AVG(price) > 1000
ORDER BY avg_price DESC;

-- 
-- Q6. Total Quantity and Orders per Customer
SELECT Customers.customer_id,
       Customers.customer_name,
       SUM(Sales.quantity)  AS total_quantity,
       COUNT(Sales.sale_id) AS number_of_orders
FROM Customers
JOIN Sales ON Customers.customer_id = Sales.customer_id
WHERE Sales.quantity > 0
GROUP BY Customers.customer_id, Customers.customer_name
ORDER BY total_quantity DESC;

-- 
-- Q7. Min Max Avg Price per Category
-- Only where min price < 5000
-- 
SELECT category,
       MIN(price)           AS min_price,
       MAX(price)           AS max_price,
       ROUND(AVG(price), 2) AS avg_price
FROM Products
GROUP BY category
HAVING MIN(price) < 5000
ORDER BY avg_price DESC;

-- 
-- Q8. Products with total sales qty > 2
-- Plus distinct customers who bought each
-- 
SELECT product_id,
       SUM(quantity)               AS total_quantity,
       COUNT(DISTINCT customer_id) AS distinct_customers
FROM Sales
GROUP BY product_id
HAVING SUM(quantity) > 2
ORDER BY total_quantity DESC;

-- Q9. Total Units and Avg Qty per Product
-- Only where total qty > 1
SELECT product_id,
       SUM(quantity)           AS total_units_sold,
       ROUND(AVG(quantity), 2) AS avg_quantity
FROM Sales
GROUP BY product_id
HAVING SUM(quantity) > 1
ORDER BY total_units_sold DESC, avg_quantity ASC;


-- Q10. qty>1, date Jan-Mar 2025, even sale_id
SELECT *
FROM Sales
WHERE quantity > 1
  AND sale_date BETWEEN '2025-01-01' AND '2025-03-01'
  AND sale_id % 2 = 0
ORDER BY sale_date DESC, quantity ASC;

-- Q11. Categories where total stock > 20

SELECT category,
       SUM(stock_quantity) AS total_stock,
       COUNT(product_id)   AS total_products
FROM Products
GROUP BY category
HAVING SUM(stock_quantity) > 20
ORDER BY total_stock DESC;

-- Q12. Formatted Names + Registration Month-Year

SELECT
    CONCAT(
        UPPER(LEFT(customer_name, 1)),
        LOWER(SUBSTRING(customer_name, 2))
    )                                       AS formatted_name,
    DATE_FORMAT(registration_date, '%b-%Y') AS registration_month_year
FROM Customers
WHERE registration_date < CURDATE()
ORDER BY registration_date DESC;